// ==========================================
// ASYNC WEATHER TRACKER - JavaScript
// Demonstrates: Async/Await, Promises, Event Loop, Local Storage
// ==========================================

// API Configuration
const API_KEY = '8ac5c4d57ba6a4b3dfcf622700447b1e'; // OpenWeatherMap API key
const API_BASE_URL = 'https://api.openweathermap.org/data/2.5/weather';

// DOM Elements
const cityInput = document.getElementById('cityInput');
const searchBtn = document.getElementById('searchBtn');
const weatherDisplay = document.getElementById('weatherDisplay');
const historyContainer = document.getElementById('historyContainer');
const consoleOutput = document.getElementById('consoleOutput');

// ==========================================
// CONSOLE LOGGING UTILITY
// ==========================================
function logToConsole(message, type = 'sync') {
    const logEntry = document.createElement('div');
    logEntry.className = `log-entry log-${type}`;
    logEntry.textContent = `▶ ${message}`;
    consoleOutput.appendChild(logEntry);
    consoleOutput.scrollTop = consoleOutput.scrollHeight;
    
    // Also log to browser console
    console.log(`[${type.toUpperCase()}] ${message}`);
}

// ==========================================
// LOCAL STORAGE FUNCTIONS
// ==========================================
function getSearchHistory() {
    logToConsole('🔍 Sync Start: Reading from Local Storage', 'sync');
    const history = localStorage.getItem('weatherHistory');
    const parsed = history ? JSON.parse(history) : [];
    logToConsole('✓ Sync End: Local Storage read complete', 'sync');
    return parsed;
}

function addToHistory(cityName) {
    logToConsole('💾 Sync Start: Saving to Local Storage', 'sync');
    let history = getSearchHistory();
    
    // Remove duplicates and add to beginning
    history = history.filter(city => city.toLowerCase() !== cityName.toLowerCase());
    history.unshift(cityName);
    
    // Keep only last 5 searches
    history = history.slice(0, 5);
    
    localStorage.setItem('weatherHistory', JSON.stringify(history));
    logToConsole('✓ Sync End: Saved to Local Storage', 'sync');
    
    displaySearchHistory();
}

function displaySearchHistory() {
    const history = getSearchHistory();
    historyContainer.innerHTML = '';
    
    if (history.length === 0) {
        historyContainer.innerHTML = '<p class="no-history">No search history yet</p>';
        return;
    }
    
    history.forEach(city => {
        const historyBtn = document.createElement('button');
        historyBtn.className = 'history-item';
        historyBtn.textContent = city;
        historyBtn.addEventListener('click', () => {
            cityInput.value = city;
            fetchWeatherData(city);
        });
        historyContainer.appendChild(historyBtn);
    });
}

// ==========================================
// WEATHER API FUNCTIONS (ASYNC/AWAIT)
// ==========================================
async function fetchWeatherData(cityName) {
    logToConsole('========================================', 'sync');
    logToConsole('🚀 Sync Start: fetchWeatherData() called', 'sync');
    
    if (!cityName || cityName.trim() === '') {
        displayError('Please enter a city name');
        logToConsole('❌ Error: Empty city name', 'error');
        return;
    }
    
    const url = `${API_BASE_URL}?q=${cityName}&appid=${API_KEY}&units=metric`;
    
    logToConsole('⏳ Before fetch() - This runs first!', 'fetch');
    logToConsole('📡 Async: Initiating HTTP request...', 'async');
    
    try {
        // Demonstrate async behavior with fetch
        const response = await fetch(url);
        
        logToConsole('📥 Async: HTTP Response received!', 'async');
        logToConsole('🔄 Event Loop: fetch() moved to task queue', 'fetch');
        
        if (!response.ok) {
            throw new Error(`City not found (Status: ${response.status})`);
        }
        
        const data = await response.json();
        logToConsole('✓ Async: JSON data parsed successfully', 'async');
        
        displayWeatherInfo(data);
        addToHistory(cityName);
        
        logToConsole('✅ Success: Weather data displayed', 'success');
        
    } catch (error) {
        logToConsole(`❌ Error caught: ${error.message}`, 'error');
        displayError(error.message);
        handleErrorWithPromise(url); // Demonstrate .then().catch()
    }
    
    logToConsole('⏰ After await - This runs after async!', 'fetch');
    logToConsole('✓ Sync End: fetchWeatherData() complete', 'sync');
    logToConsole('========================================', 'sync');
}

// ==========================================
// ERROR HANDLING WITH .then() / .catch()
// Demonstrates promise-based error handling
// ==========================================
function handleErrorWithPromise(url) {
    logToConsole('🔄 Demo: Using .then()/.catch() pattern', 'async');
    
    fetch(url)
        .then(response => {
            logToConsole('▶ .then() - Promise resolved', 'async');
            if (!response.ok) {
                throw new Error('Promise chain error');
            }
            return response.json();
        })
        .then(data => {
            logToConsole('▶ .then() - Data received in chain', 'async');
        })
        .catch(error => {
            logToConsole(`▶ .catch() - Error handled: ${error.message}`, 'error');
        });
}

// ==========================================
// DISPLAY FUNCTIONS
// ==========================================
function displayWeatherInfo(data) {
    const { name, sys, main, weather, wind } = data;
    
    weatherDisplay.innerHTML = `
        <div class="weather-info">
            <h3>${name}, ${sys.country}</h3>
            
            <div class="weather-detail">
                <span class="weather-label">Temperature</span>
                <span class="weather-value">${Math.round(main.temp)}°C</span>
            </div>
            
            <div class="weather-detail">
                <span class="weather-label">Weather</span>
                <span class="weather-value">${weather[0].main}</span>
            </div>
            
            <div class="weather-detail">
                <span class="weather-label">Humidity</span>
                <span class="weather-value">${main.humidity}%</span>
            </div>
            
            <div class="weather-detail">
                <span class="weather-label">Wind Speed</span>
                <span class="weather-value">${wind.speed} m/s</span>
            </div>
            
            <div class="weather-detail">
                <span class="weather-label">Feels Like</span>
                <span class="weather-value">${Math.round(main.feels_like)}°C</span>
            </div>
        </div>
    `;
}

function displayError(message) {
    weatherDisplay.innerHTML = `
        <div class="error-message">
            <strong>⚠️ Error:</strong><br>
            ${message}
        </div>
    `;
}

// ==========================================
// EVENT LISTENERS
// ==========================================
searchBtn.addEventListener('click', () => {
    logToConsole('👆 Click Event: Search button clicked', 'sync');
    const city = cityInput.value.trim();
    fetchWeatherData(city);
});

cityInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        logToConsole('⌨️ Keypress Event: Enter key pressed', 'sync');
        const city = cityInput.value.trim();
        fetchWeatherData(city);
    }
});

// ==========================================
// EVENT LOOP DEMONSTRATION
// ==========================================
function demonstrateEventLoop() {
    logToConsole('========================================', 'sync');
    logToConsole('📚 Event Loop Demonstration Starting...', 'sync');
    
    console.log('1. Synchronous code - executes first');
    logToConsole('1️⃣ Synchronous code - Call Stack', 'sync');
    
    setTimeout(() => {
        console.log('2. setTimeout - executes last (Task Queue)');
        logToConsole('2️⃣ setTimeout callback - Task Queue', 'async');
    }, 0);
    
    Promise.resolve().then(() => {
        console.log('3. Promise - executes second (Microtask Queue)');
        logToConsole('3️⃣ Promise.then() - Microtask Queue', 'async');
    });
    
    console.log('4. More synchronous code');
    logToConsole('4️⃣ More synchronous - Call Stack', 'sync');
    
    logToConsole('✓ Event Loop Demo: Code execution order logged', 'sync');
    logToConsole('========================================', 'sync');
}

// ==========================================
// INITIALIZATION
// ==========================================
window.addEventListener('DOMContentLoaded', () => {
    logToConsole('🌟 App Initialized - DOMContentLoaded', 'sync');
    displaySearchHistory();
    demonstrateEventLoop();
    logToConsole('Ready to search weather! 🌤', 'success');
});

// ==========================================
// NOTES FOR LEARNING
// ==========================================
/*
EVENT LOOP FLOW:
1. Call Stack: Synchronous code executes immediately
2. Web APIs: async operations (fetch, setTimeout) handled by browser
3. Callback Queue: setTimeout, setInterval callbacks wait here
4. Microtask Queue: Promise callbacks (.then, .catch) - Higher Priority!
5. Event Loop: Moves tasks from queues to call stack when empty

EXECUTION ORDER:
- Synchronous code (Call Stack)
- Microtasks (Promises) - Higher Priority
- Macrotasks (setTimeout, setInterval)

PROMISE STATES:
- Pending: Initial state
- Fulfilled: Operation completed successfully
- Rejected: Operation failed

ASYNC/AWAIT vs .then()/.catch():
- async/await: Cleaner, more readable (syntactic sugar over promises)
- .then()/.catch(): Traditional promise chaining
- Both handle the same underlying promise mechanism
*/
