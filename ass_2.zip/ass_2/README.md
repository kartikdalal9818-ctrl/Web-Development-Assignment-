# 🌤 Async Weather Tracker

A hands-on lab assignment demonstrating asynchronous JavaScript programming, promises, error handling, and the event loop.

## 📋 Assignment Requirements Met

### ✅ Functional Requirements

1. **Weather Search Interface**
   - ✓ Input field for city name
   - ✓ Search button to fetch weather
   - ✓ Displays city, temperature, weather condition, humidity, and wind speed

2. **Asynchronous API Handling**
   - ✓ Uses `async/await` for API calls
   - ✓ Fetches from OpenWeatherMap API
   - ✓ Demonstrates promise-based async operations

3. **Error Handling & Promise States**
   - ✓ Handles invalid city names gracefully
   - ✓ Network error handling
   - ✓ Uses both `try...catch` and `.then()/.catch()` patterns
   - ✓ User-friendly error messages

4. **Local Storage - Search History**
   - ✓ Stores previous searches in Local Storage
   - ✓ Displays recent searches on page load
   - ✓ Click history items to re-fetch weather
   - ✓ Maintains last 5 searches

5. **Event Loop & Execution Order Analysis**
   - ✓ Console logs track execution order
   - ✓ Demonstrates sync vs async behavior
   - ✓ Logs before/after fetch calls
   - ✓ Visual console display in UI
   - ✓ Color-coded log types

## 🚀 How to Run

### Option 1: Direct File Opening
1. Download all three files: `index.html`, `styles.css`, `script.js`
2. Keep them in the same folder
3. Double-click `index.html` to open in your browser

### Option 2: Local Server (Recommended)
```bash
# Using Python 3
python -m http.server 8000

# Using Node.js (http-server)
npx http-server

# Then open: http://localhost:8000
```

## 🎯 How to Use

1. **Search for Weather:**
   - Enter a city name (e.g., "London", "Mumbai", "Tokyo")
   - Click "Search" or press Enter
   - View weather information on the right panel

2. **View Search History:**
   - Previously searched cities appear as orange buttons
   - Click any history button to quickly re-search that city
   - History persists even after page reload (Local Storage)

3. **Monitor Event Loop:**
   - Watch the console panel at the bottom
   - Color-coded logs show execution order:
     - 🟢 Green: Synchronous operations
     - 🔵 Blue: Asynchronous operations
     - 🟡 Yellow: Fetch-related logs
     - 🔴 Red: Error handling
     - 💚 Light Green: Success messages

## 🔍 Key Learning Concepts Demonstrated

### 1. Async/Await
```javascript
async function fetchWeatherData(cityName) {
    const response = await fetch(url);
    const data = await response.json();
    // ... handle data
}
```

### 2. Promise Error Handling
```javascript
// Try-Catch Pattern
try {
    const response = await fetch(url);
} catch (error) {
    console.error(error);
}

// .then().catch() Pattern
fetch(url)
    .then(response => response.json())
    .catch(error => console.error(error));
```

### 3. Event Loop Behavior
- **Call Stack**: Synchronous code executes first
- **Microtask Queue**: Promise callbacks (higher priority)
- **Callback Queue**: setTimeout, async callbacks
- **Event Loop**: Manages execution order

### 4. Local Storage
```javascript
// Save data
localStorage.setItem('key', JSON.stringify(data));

// Retrieve data
const data = JSON.parse(localStorage.getItem('key'));
```

## 📊 Grading Rubric

| Criteria      | Marks | Status |
|---------------|-------|--------|
| Functionality | 1.5   | ✅     |
| UI            | 0.5   | ✅     |
| Clean Code    | 0.5   | ✅     |
| **Total**     | **2.5** | **✅** |

## 🛠 Technology Stack

- **HTML5**: Semantic structure
- **CSS3**: Modern styling with animations
- **Vanilla JavaScript**: No frameworks/libraries
- **OpenWeatherMap API**: Free weather data

## 🎨 Features

### UI Features
- Clean, modern interface with dark blue theme
- Responsive design (mobile-friendly)
- Smooth animations and transitions
- Real-time console display
- Error message styling

### Technical Features
- RESTful API integration
- Asynchronous data fetching
- Promise-based error handling
- Persistent data storage
- Event-driven architecture
- DOM manipulation

## 📝 Code Structure

```
async-weather-tracker/
│
├── index.html       # Main HTML structure
├── styles.css       # Styling and layout
└── script.js        # JavaScript logic
    ├── API calls (async/await)
    ├── Error handling (try-catch + promises)
    ├── Local Storage operations
    ├── Event loop demonstration
    └── DOM manipulation
```

## 🔑 API Key Note

The code includes a demo OpenWeatherMap API key. For production use:

1. Sign up at [OpenWeatherMap](https://openweathermap.org/api)
2. Get your free API key
3. Replace the API_KEY in `script.js`:
```javascript
const API_KEY = 'YOUR_API_KEY_HERE';
```

## 🐛 Common Issues & Solutions

**Issue**: Weather not loading
- **Solution**: Check internet connection or try a different city name

**Issue**: Console not showing logs
- **Solution**: Open browser DevTools (F12) to see additional console output

**Issue**: History not saving
- **Solution**: Ensure browser allows Local Storage (not in private/incognito mode)

## 📚 Additional Learning Resources

- [MDN - Async/Await](https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Asynchronous/Async_await)
- [MDN - Promises](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise)
- [Event Loop Visualizer](http://latentflip.com/loupe/)
- [OpenWeatherMap API Docs](https://openweathermap.org/api)

## 🎓 Learning Outcomes

After completing this assignment, you should understand:

1. ✅ How async/await simplifies asynchronous code
2. ✅ The difference between promises and callbacks
3. ✅ How the JavaScript event loop works
4. ✅ Error handling patterns in async code
5. ✅ Browser Local Storage API
6. ✅ Real-world API integration
7. ✅ DOM manipulation and event handling

---

**Happy Coding!** 🎯

*Built for Web Dev II (Advanced JS & React) - Assignment 2*
